# Front-end do DesapegaUai

React + Vite. Para rodar: `npm install` e depois `npm run dev`. O site abre em <http://localhost:5173>.

A API precisa estar rodando junto (veja o [README da raiz](../README.md)). Em desenvolvimento, o Vite repassa tudo o que começa com `/api` para o back-end (`vite.config.js`).

## Onde fica cada coisa

| Pasta | O que vai nela |
| --- | --- |
| `src/pages/` | Uma tela por arquivo (`Inicio.jsx`, `Favoritos.jsx`...). Toda tela nova entra nas rotas do `src/App.jsx`. |
| `src/components/` | Partes que se repetem entre as telas: cabeçalho, rodapé, card de anúncio, botões. |
| `src/services/api.js` | Chamadas para o back-end: `api.get('/rota')`, `api.post('/rota', dados)`. |
| `src/contexts/` | Estado compartilhado entre as telas (ex.: usuário logado). |
| `src/hooks/` | Hooks próprios (`useAlgumaCoisa.js`). |
| `src/styles/global.css` | CSS global e as cores da marca em variáveis (`var(--cor-principal)`). |
| `src/assets/` | Imagens e ícones usados no código. |
| `public/` | Arquivos usados como estão, sem passar pelo código (logo, favicon). |

A `Inicio.jsx` que está aí é provisória: ela só confere se o front está falando com a API. Podem trocar pela Home do Figma.

## Comandos

| Comando | O que faz |
| --- | --- |
| `npm run dev` | Roda o site em modo de desenvolvimento |
| `npm run build` | Gera a versão final na pasta `dist/` |
| `npm run preview` | Abre a versão final gerada pelo build |
| `npm run lint` | Procura erros no código |

## Combinados

- Componentes e páginas com nome em PascalCase: `CardAnuncio.jsx`, `MeusAnuncios.jsx`.
- A API é chamada sempre pelo `services/api.js`, nunca com `fetch` direto nas telas.
- Cores pelas variáveis do `global.css`, sem repetir o código da cor em cada arquivo.

## Login (`/entrar`)

A tela de login está em `src/pages/Login.jsx`, e o estilo dela em `Login.css`. Ela abre em <http://localhost:5173/entrar>.

- O login é pelo Google. Quando a pessoa entra, a API confere a conta com o Google, cria o usuário no banco no primeiro acesso e grava o cookie de login. A tela usa as rotas `POST /api/auth/google`, `GET /api/auth/sessao` e `POST /api/auth/logout`.
- O botão do Google só funciona se o `.env` tiver o `VITE_GOOGLE_CLIENT_ID`. Copie o `.env.example` para `.env` e coloque o mesmo valor do `GOOGLE_CLIENT_ID` do `backend/.env`. Depois de mudar o `.env`, pare o `npm run dev` e rode de novo.
- Abra sempre pelo endereço `http://localhost:5173`, e não pelo IP da rede. O Google só aceita os endereços que foram cadastrados no Google Cloud.
- Os campos de e-mail e senha, o "Esqueceu a senha?", o botão da Apple e o "Criar conta" fazem parte do design, mas a API ainda não tem essas rotas. Por enquanto eles só mostram um aviso.
- A animação do logo está em `src/components/LogoAnimado.jsx`.
- Os avisos rápidos que aparecem no alto da tela são o `src/components/Toast.jsx`. Ele pode ser usado nas outras telas também.
