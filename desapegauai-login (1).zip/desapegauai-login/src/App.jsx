import { Route, Routes } from 'react-router'
import Inicio from './pages/Inicio.jsx'
import Login from './pages/Login.jsx'
import NaoEncontrada from './pages/NaoEncontrada.jsx'

// Rotas (páginas) do site. Cada página nova entra aqui com um <Route>.
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Inicio />} />
      <Route path="/entrar" element={<Login />} />
      <Route path="*" element={<NaoEncontrada />} />
    </Routes>
  )
}
